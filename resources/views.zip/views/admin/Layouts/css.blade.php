<!--     Fonts and icons     -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
<!-- Nucleo Icons -->
<link href={{ asset('dist/assets/css/nucleo-icons.css') }} rel="stylesheet" />
<link href={{ asset('dist/assets/css/nucleo-svg.css') }} rel="stylesheet" />
<!-- Font Awesome Icons -->
<script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
<link href={{ asset('dist/assets/css/nucleo-svg.css') }} rel="stylesheet" />
<!-- CSS Files -->
<link id="pagestyle" href={{ asset('dist/assets/css/soft-ui-dashboard.css?v=1.0.3') }} rel="stylesheet" />

{{-- Data Tables --}}
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.0/css/dataTables.dataTables.css" />

{{-- Izi Toast --}}
<link rel="stylesheet" href="{{ asset('dist/assets/scss/iziToast.min.css') }}">
