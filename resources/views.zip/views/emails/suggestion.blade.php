<h3>Pesan Baru dari Website</h3>

<p><strong>Nama:</strong> {{ $suggestion->name }}</p>
<p><strong>Email:</strong> {{ $suggestion->email }}</p>
<p><strong>Subjek:</strong> {{ $suggestion->subject }}</p>
<p><strong>Pesan:</strong></p>
<p>{{ $suggestion->message }}</p>
