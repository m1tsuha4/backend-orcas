<!-- Vendor CSS Files -->
<link
    href="{{ asset('dist_front/assets/vendor/bootstrap/css/bootstrap.min.css') }}"
    rel="stylesheet"
/>
<link
    href="{{ asset('dist_front/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}"
    rel="stylesheet"
/>
<link href="{{ asset('dist_front/assets/vendor/aos/aos.css') }}" rel="stylesheet" />
<link href="{{ asset('dist_front/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet" />
<link
    href="{{ asset('dist_front/assets/vendor/glightbox/css/glightbox.min.css') }}"
    rel="stylesheet"
/>

<!-- Main CSS File -->
<link href="{{ asset('dist_front/assets/css/main.css') }}" rel="stylesheet" />

{{-- Izi Toast --}}
<link rel="stylesheet" href="{{ asset('dist/assets/scss/iziToast.min.css') }}">
